#include <stc12c5a.h>
#include "duoji.h"
#define uchar unsigned char 
#define uint unsigned int 

void main()
{	while (1)
	{
	douji(130,2,4);
	}
 		

}