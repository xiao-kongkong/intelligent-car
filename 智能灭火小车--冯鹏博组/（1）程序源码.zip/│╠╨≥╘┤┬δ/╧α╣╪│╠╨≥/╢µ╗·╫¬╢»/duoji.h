#ifndef   DUOJI_H
#define   DUOJI_H

void douji(unsigned int x,unsigned char m,unsigned char n);
#endif