#ifndef   __shengbo_H__
#define   __shengbo_H__

#define uchar unsigned char
#define uint unsigned int
sbit flame1 = P3^5;  //�����Ӧ	zuo
sbit flame2 = P3^6;	 // 		zhong
sbit flame3 = P3^7;	 //			you
	 void txbo (uchar i);
	 void cebo ();
	 void Conut(uchar i);
	 void zhongduan();
	 void chao ();

#endif