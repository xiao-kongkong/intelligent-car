#ifndef   car_H
#define   car_H

sbit rig=P0^1;
sbit lif=P0^2;

sbit rig0=P0^3;
sbit lif0=P0^4;
void car(unsigned long x,unsigned long y); 
#endif

