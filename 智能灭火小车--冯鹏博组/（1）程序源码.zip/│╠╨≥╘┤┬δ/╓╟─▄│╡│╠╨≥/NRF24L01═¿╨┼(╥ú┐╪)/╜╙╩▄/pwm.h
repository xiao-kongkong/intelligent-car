#ifndef   PWM_H
#define   PWM_H

void pwm(unsigned char x,unsigned char y);
#endif