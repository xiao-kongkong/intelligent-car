#ifndef   DUOJI_H
#define   DUOJI_H
#define uchar unsigned char
#define uint  unsigned int
 sbit pwm0 =P0^0 ; 
extern uchar m ;
extern uchar count; 
 extern unsigned char jd;
 void douji1(uint x,uchar m);
void douji2(uint x,uchar m)	;
#endif