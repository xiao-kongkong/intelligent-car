#ifndef   POW_H
#define   POW_H

void pow();
void pows();
#endif